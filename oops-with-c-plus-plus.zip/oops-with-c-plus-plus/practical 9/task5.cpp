#include<iostream>
using namespace std;
class college
{
	string name;
	int students;
};
struct student
{
	string name;
	int ns;
};
int main()
{
	struct student s;
	college s2;
}
