#include<iostream>
#include<string>
using namespace std;
int main()
{
   string b="Hello";
   b[0]='j';
   cout<<b;
}
   
