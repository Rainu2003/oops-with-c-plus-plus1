#include<iostream>
using namespace std;
int main()
{
 string a="oops";
 string b="with c plus plus";
 int c=9;
 int d=10;
 //int res=c+d;
 //string res1=a+b;
 string res2=a+c;
 //cout<<res<<endl;
 //cout<<res1<<endl;
 cout<<res2<<endl;
}
 
