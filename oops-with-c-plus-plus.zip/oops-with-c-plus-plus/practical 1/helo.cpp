#include<iostream>
using namespace std;
#define MAX 100
int main()
{
cout<<"hello world"<<MAX;
return 0;
}
