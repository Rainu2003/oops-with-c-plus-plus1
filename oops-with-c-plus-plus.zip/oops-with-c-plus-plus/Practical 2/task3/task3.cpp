#include<iostream>
using namespace std;
int main()
{
char a;
cin>>a;
cout<<a;
}
