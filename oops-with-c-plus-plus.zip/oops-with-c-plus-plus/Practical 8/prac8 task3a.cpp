#include<iostream>
using namespace std;
int main()
{
 int arr[]={10,20,30};
 cout<< *arr<<endl;
 arr++;
 cout<< *arr<<endl;
 return 0;
 }
 
